﻿init -1 transform glitch_bg_anim:
    xsize 1920 ysize 1080
    block:
        xoffset 0 yoffset 0 alpha 1.0
        linear 0.05 xoffset -15 yoffset 5 alpha 0.8
        linear 0.05 xoffset 20 yoffset -10 alpha 0.95
        linear 0.05 xoffset -5 yoffset 15 alpha 0.7
        linear 0.1  xoffset 0 yoffset 0 alpha 1.0
        pause 0.2
        repeat

# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Eileen")


# The game starts here.

image bg_room_timur_1 = Transform("images/bg_room_timur_1.jpg", xsize=1920, ysize=1080)

label start:

    play music "audio/main_menu_theme.ogg" fadein 1.0

    # Сцена 1. Пробуждение
    scene bg_room_timur_1 with dissolve

    "Тимур просыпается в своей комнате после продолжительной болезни. Он чувствует тяжесть в голове и слабость. Комната погружена в тусклый утренний свет."

    # Мысли Тимура (используем narrator без имени или оформляем как внутренний монолог)
    "Тимур (про себя): Голова тяжёлая... Сколько я проспал? Кажется, температура наконец спала."

    "Тимур (про себя): В ушах всё ещё звенит от этого душного бреда."

    # Плавное затемнение для перехода к следующей сцене
    scene black with fade
    
    return


    transform glitch_bg_anim:
    # Растягиваем на весь экран
        xsize 1920 ysize 1080
    
    # Бесконечный цикл глитча
        block:
            xoffset 0 yoffset 0 alpha 1.0
            linear 0.05 xoffset -15 yoffset 5 alpha 0.8
            linear 0.05 xoffset 20 yoffset -10 alpha 0.95
            linear 0.05 xoffset -5 yoffset 15 alpha 0.7
            linear 0.1  xoffset 0 yoffset 0 alpha 1.0
            pause 0.2  # Пауза перед следующим рывком
            repeat